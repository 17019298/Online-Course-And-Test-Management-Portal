package sunbeam.ocm;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import sunbeam.ocm.daos.StudentDao;
import sunbeam.ocm.dtos.Credentials;
import sunbeam.ocm.dtos.DtoEntityConverter;
import sunbeam.ocm.dtos.StudentDto;
import sunbeam.ocm.entities.Student;

@SpringBootTest
class OnlineCourseManagement1ApplicationTests {
@Autowired
private StudentDao studentDao;
@Autowired
private DtoEntityConverter dtoEntityConverter;
@Autowired
private Credentials cred;
	@Test
	public StudentDto getStudentByEmialAndPassword(Credentials cred ) {
		Student dbStudent = studentDao.findByEmail(cred.getEmail());
//		String rawPassword = cred.getPassword();
//		if(dbStudent != null && passwordEncoder.matches(rawPassword, dbStudent.getPassword())) {
//			StudentDto result = dtoEntityConverter.toStudentDto(dbStudent);
//			result.setPassword("********");
//			return result;
//		}
		if(dbStudent!=null&&cred.getPassword().equals(dbStudent.getPassword())) {
			StudentDto result = dtoEntityConverter.toStudentDto(dbStudent);
			System.out.println(result);
			return result;
		}
		return null;
	}
	
}
