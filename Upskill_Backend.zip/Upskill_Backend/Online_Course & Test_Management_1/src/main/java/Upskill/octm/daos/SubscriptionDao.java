package sunbeam.ocm.daos;

import org.springframework.data.jpa.repository.JpaRepository;

import sunbeam.ocm.entities.Subscription;

public interface SubscriptionDao extends JpaRepository<Subscription, Integer> {

}
