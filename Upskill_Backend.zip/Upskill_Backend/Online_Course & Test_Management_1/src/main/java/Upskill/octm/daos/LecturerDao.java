package sunbeam.ocm.daos;

import org.springframework.data.jpa.repository.JpaRepository;

import sunbeam.ocm.entities.Lecturer;

public interface LecturerDao extends JpaRepository<Lecturer, Integer>{
	Lecturer findByLecturerId(int id);
	Lecturer findByEmail(String email);
}
