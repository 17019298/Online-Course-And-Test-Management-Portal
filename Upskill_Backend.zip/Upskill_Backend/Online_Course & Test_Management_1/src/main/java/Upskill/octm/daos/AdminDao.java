package sunbeam.ocm.daos;

import org.springframework.data.jpa.repository.JpaRepository;

import sunbeam.ocm.entities.Admin;

public interface AdminDao extends JpaRepository<Admin, Integer> {
	Admin findByAdminId(int id);
	Admin findByEmail(String email);
}
